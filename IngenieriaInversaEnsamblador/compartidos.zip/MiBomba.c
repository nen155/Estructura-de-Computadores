#include <stdio.h>    // para printf()
#include <stdlib.h>   // para exit()
#include <string.h>   // para strncmp()/strlen()
#include <sys/time.h> // para gettimeofday(), struct timeval

char passcode[]="helado de caramelo\n";
int  password  = 1234;

void defused()
{
	printf("***************\n");
	printf("*** BOOM!!! ***\n");
	printf("***************\n");
	exit(0);
}

void boom()
{
	printf("·························\n");
	printf("··· bomba desactivada ···\n");
	printf("·························\n");
	exit(-1);
}

int main()
{

#define SIZE 100
	char pass[SIZE];
	int  pasv;

#define TLIM 20
	struct timeval tv1,tv2;	// gettimeofday() secs-usecs

	gettimeofday(&tv1,NULL);

	printf("Introduce el código: ");
	fgets(pass,SIZE,stdin);
	if (strncmp(pass,passcode,strlen(passcode)))
		defused();

	gettimeofday(&tv2,NULL);
	if (tv1.tv_sec - tv2.tv_sec > TLIM)
		defused();

	printf("Introduce la contraseña: ");
	scanf("%i",&pasv);
	if (pasv!=password)
		defused();

	gettimeofday(&tv1,NULL);
	if (tv2.tv_sec - tv1.tv_sec > TLIM)
		defused();

	boom();

	return 0;
}
